package com.fpt.khangpq.se1706recyclerview;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class SMSRcvAdapter extends RecyclerView.Adapter<SMSRcvAdapter.VH> {
    private List<SMS> data;
    private Context context;
    private LayoutInflater inflater;

    public SMSRcvAdapter(List<SMS> data, Context context) {
        this.data = data;
        this.context = context;
        inflater = LayoutInflater.from(context);
    }

    public void setData(List<SMS> data) {
        this.data = data;
        notifyDataSetChanged();
    }

    protected class VH extends RecyclerView.ViewHolder {
        private TextView tvPhoneNumber;
        private TextView tvSmsContent;

        private void bindingView() {
            tvPhoneNumber = itemView.findViewById(R.id.tvPhoneNumber);
            tvSmsContent = itemView.findViewById(R.id.tvSmsContent);
        }

        private void bindingAction() {
            tvPhoneNumber.setOnClickListener(this::onTvClick);
            tvSmsContent.setOnClickListener(this::onTvClick);
            itemView.setOnClickListener(this::onItemViewClick);
        }

        private void onItemViewClick(View view) {
            Toast.makeText(context, tvPhoneNumber.getText() + "---" +
                    tvSmsContent.getText(), Toast.LENGTH_SHORT).show();
        }

        private void onTvClick(View view) {
            Toast.makeText(context, ((TextView) view).getText(), Toast.LENGTH_SHORT).show();
        }

        public VH(@NonNull View itemView) {
            super(itemView);
            bindingView();
            bindingAction();
        }

        public void setSMS(SMS sms) {
            tvPhoneNumber.setText(sms.getPhoneNumber());
            tvSmsContent.setText(sms.getSmsContent());

        }
    }

    int count = 0;

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        count++;
        Log.d("KhangPQ.Debug", "count= " + count);
        View v = inflater.inflate(R.layout.sms_item, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        SMS sms = data.get(position);
        holder.setSMS(sms);
    }

    @Override
    public int getItemCount() {
        return data.size();
    }
}
