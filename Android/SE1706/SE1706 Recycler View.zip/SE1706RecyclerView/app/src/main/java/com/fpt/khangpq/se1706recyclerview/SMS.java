package com.fpt.khangpq.se1706recyclerview;

public class SMS {
    private String phoneNumber;
    private String smsContent;

    public SMS() {
    }

    public SMS(String phoneNumber, String smsContent) {
        this.phoneNumber = phoneNumber;
        this.smsContent = smsContent;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getSmsContent() {
        return smsContent;
    }

    public void setSmsContent(String smsContent) {
        this.smsContent = smsContent;
    }
}
