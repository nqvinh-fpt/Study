package com.fpt.khangpq.se1706sqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBContext extends SQLiteOpenHelper {

    private static final int DB_VERSION = 3;
    private static final String DB_NAME = "contact";
    public static final String TB_CONTACT = "contact";
    public static final String TB_CONTACT_COL_NAME = "name";
    public static final String TB_CONTACT_COL_PHONE = "phone";

    public DBContext(@Nullable Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    public void insertContact(Contact c) {
        String sql = "INSERT INTO contact (name, phone) VALUES (?,? )";
        getWritableDatabase().execSQL(sql, new Object[]{c.getName(), c.getPhone()});
    }

    public long insertContact2(Contact c) {
        ContentValues value = new ContentValues();
        value.put(TB_CONTACT_COL_NAME, c.getName());
        value.put(TB_CONTACT_COL_PHONE, c.getPhone());
        return getWritableDatabase().insert(TB_CONTACT, null, value);
    }

    public Cursor getAllContact() {
        String sql = "Select * from contact";
        return getReadableDatabase().rawQuery(sql, null);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = " create table contact \n" +
                "(\n" +
                "    id    integer     not null\n" +
                "        constraint contact_pk\n" +
                "            primary key autoincrement,\n" +
                "    name  text,\n" +
                "    phone varchar(20) not null\n" +
                ")";
        db.execSQL(sql);
        db.execSQL("create unique index contact_phone_uindex\n" +
                "    on contact (phone)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion <= 1 && newVersion >= 2) {
            //code migrate from ver 1 to ver 2
        }
        if (oldVersion <= 2 && newVersion >= 3) {
            //code migrate from ver 2 to ver 3
        }
    }
}
