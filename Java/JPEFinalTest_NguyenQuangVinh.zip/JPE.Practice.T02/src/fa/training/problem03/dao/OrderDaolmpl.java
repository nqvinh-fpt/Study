package fa.training.problem03.dao;

import fa.training.problem03.models.Order;
import fa.training.problem03.models.OrderDetail;

import java.sql.*;

public class OrderDaolmpl {

}

