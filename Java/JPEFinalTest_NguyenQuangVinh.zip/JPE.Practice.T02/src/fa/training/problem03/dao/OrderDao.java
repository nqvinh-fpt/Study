package fa.training.problem03.dao;

import fa.training.problem03.models.Order;
import fa.training.problem03.models.OrderDetail;
import fa.training.utils.Validator.Validator;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OrderDao {
    private Connection connection;

    public OrderDao() {
        // Initialize the database connection here
        try {
            String connectionUrl = "jdbc:sqlserver://localhost:1433;encrypt=true;trustServerCertificate=true;databaseName=InventorySystem;user=sa;password=123";
            connection = DriverManager.getConnection(connectionUrl);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public String save(Order order) {
        try {
            String insertOrderSQL = "INSERT INTO Orders (Orders, OrderDeals, de, pede, unt, pride) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(insertOrderSQL);
            preparedStatement.setString(1, String.valueOf(order.getOrderID()));


            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                return "success";
            } else {
                return "fail";
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return "fail";
        }
    }

    public Order createOrder() {
        int orderID;
        String orderDate;
        String requiredDate;
        String customerID;
        double totalPrice;
        while (true) {
            orderID = Validator.inputNumber("Enter Order ID: ");
            while (true) {
                orderDate = Validator.inputString("Enter Order Date: ");
                if (Validator.isValidDate(orderDate)) {
                    break;
                }
            }
            while (true) {
                requiredDate = Validator.inputString("Enter Required Date: ");
                if (Validator.isValidDate(requiredDate)) {
                    break;
                }
            }
            customerID = Validator.inputString("Enter Customer ID: ");
            totalPrice = Validator.inputDouble("Enter Total Price: ", 0);
            break;
        }
        Order order = new Order(orderID, orderDate, requiredDate, customerID, totalPrice);
        return order;
    }
    public OrderDetail createOrderDetail() {
        int orderDetailID;
        int orderID;
        String productName;
        int quantity;
        double pricePerUnit;
        double totalPrice;
        while (true) {
            orderDetailID = Validator.inputNumber("Enter Order ID: ");
            orderID = Validator.inputNumber("Enter Order ID: ");
            productName= Validator.inputString("Enter Product Name: ");
            quantity =Validator.inputNumber("Enter Quantity: ");
            pricePerUnit = Validator.inputDouble("Enter PricePer Unit",0);
            totalPrice = Validator.inputDouble("Enter Total Price",0);
            break;
        }
        OrderDetail orderDetail = new OrderDetail(orderDetailID, orderID,productName,quantity, pricePerUnit,totalPrice);
        return orderDetail;
    }

    public String save(OrderDetail orderDetail) {
        try {
            String insertOrderDetailSQL = "INSERT INTO OrderDetails (OrderID, ProductName, Quantity, PricePerUnit, TotalPrice) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(insertOrderDetailSQL);
            preparedStatement.setString(1,String.valueOf(orderDetail.getOrderId()));


            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                return "success";
            } else {
                return "fail";
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return "fail";
        }
    }

    public Map<String, Double> reportOfSale() {
        Map<String, Double> salesReport = new HashMap<>();
        salesReport.put("Customer1", 150.0);
        salesReport.put("Customer2", 200.0);

        return salesReport;
    }

    public List<Order> findOrderByCustomer(String customerId) {

        List<Order> customerOrders = new ArrayList<>();

        return customerOrders;
    }

    public double calculateTotalMoney(String customerId, List<Order> orders) {
        double totalMoney = 0.0;
        System.out.println("Total money");
        for (Order order : orders) {
            if (order.getCustomerID().equals(customerId)) {
                totalMoney += order.getTotalPrice();
            }
        }
        return totalMoney;
    }

    public void displayListOrder(List<Order> orders){
        System.out.println("------List order-------");
        for (Order orderList : orders) {
            System.out.printf("%-10s  %-20s  %-20s %-20s %-20s%n", orderList.getOrderID(),orderList.getOrderDate(),orderList.getRequiredDate(),orderList.getCustomerID(),orderList.getTotalPrice());

        }
    }
}
