package fa.training.utils;

public class Constants {
    public static final String CUSTOMER_DATA_FILE = "customer.dat";
    }