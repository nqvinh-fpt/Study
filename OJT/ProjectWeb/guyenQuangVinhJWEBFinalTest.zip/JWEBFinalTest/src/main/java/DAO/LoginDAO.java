/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import DAL.DBContext;
import Model.Account;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author vinh1
 */
public class LoginDAO extends DBContext {

    public Account checkLoginUser(String userName, String pass) {
        String sql = "SELECT [account]\n"
                + "      ,[password]\n"
                + "      ,[phone]\n"
                + "      ,[balance]\n"
                + "  FROM [Account]  where account = ? and password = ?";
        try {
            PreparedStatement st = connection.prepareStatement(sql);
            st.setString(1, userName);
            st.setString(2, pass);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                Account account = new Account(rs.getString("account"),
                        rs.getString("password"),
                        rs.getString("phone"),
                        rs.getLong("balance")
                );
                return account;
            }
        } catch (SQLException e) {
            System.out.println("error login db");
        }
        return null;
    }
}
