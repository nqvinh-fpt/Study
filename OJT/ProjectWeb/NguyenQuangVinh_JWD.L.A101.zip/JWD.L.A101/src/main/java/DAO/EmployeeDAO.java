/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Entity.Employee;
import Entity.User;
import dal.DBContext;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author vinh1
 */
public class EmployeeDAO extends DBContext {

    public void addEmployee(String first_name, String last_name, int gender, String date_of_birth, String phone, String address, String department_name, String remark) {
        String insert = "INSERT INTO [dbo].[Employee]\n"
                + "           ([first_name]\n"
                + "           ,[last_name]\n"
                + "           ,[gender]\n"
                + "           ,[date_of_birth]\n"
                + "           ,[phone]\n"
                + "           ,[address]\n"
                + "           ,[department_name]\n"
                + "           ,[remark])\n"
                + "     VALUES\n"
                + "           (?,?,?,?,?,?,?,?)";
        try {
            PreparedStatement ps = connection.prepareStatement(insert);
            ps.setString(1, first_name);
            ps.setString(2, last_name);
            ps.setInt(3, gender);
            ps.setString(4, date_of_birth);
            ps.setString(5, phone);
            ps.setString(6, address);
            ps.setString(7, department_name);
            ps.setString(8, remark);
            ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Create Account Error!!"+e);
        }
    }

    public int getEmployeeLast() {
        try{
            String sql = "SELECT TOP 1 employee_id FROM Employee\n"
                + "ORDER BY employee_id DESC";
        PreparedStatement st = connection.prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                String employee_id = rs.getString(1);
                return Integer.parseInt(employee_id) ;
            }
        } catch (Exception e) {
            System.out.println("getListUser: " + e.getMessage());
        }
        return 0;        
    }

    public ArrayList<Employee> getListEmployee() {
        ArrayList<Employee> data = new ArrayList<>();
        try {
            String strSelect = "SELECT [employee_id]"
                    + "      ,[first_name]\n"
                    + "      ,[last_name]\n"
                    + "      ,[gender]\n"
                    + "      ,[date_of_birth]\n"
                    + "      ,[phone]\n"
                    + "      ,[address]\n"
                    + "      ,[department_name]\n"
                    + "      ,[remark]\n"
                    + "  FROM [Employee]";
            PreparedStatement st = connection.prepareStatement(strSelect);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                String employee_id = rs.getString(1);
                String firstName = rs.getString(2);
                String lastName = rs.getString(3);
                String gender = rs.getString(4);
                switch (Integer.parseInt(gender)) {
                    case 1:
                        gender = "male";
                        break;
                    case 0:
                        gender = "female";
                        break;
                    default:
                        gender = "null";
                        break;
                }
                String date_of_birth = rs.getString(5);
                String phone = rs.getString(6);
                String address = rs.getString(7);
                String department_name = rs.getString(8);
                String remark = rs.getString(9);
                Employee employee = new Employee(employee_id, firstName, lastName, gender, date_of_birth, phone, address, department_name, remark);
                data.add(employee);
            }
        } catch (Exception e) {
            System.out.println("getListUser: " + e.getMessage());
        }
        return data;
    }

    public int getSizeOfList(String key, String searchType) {
        String sql = "select count(employee_id) FROM [dbo].Employee";
        if (key != null && !key.isEmpty()) {
            if (searchType.equals("name")) {
                sql += " where (first_name like N'%" + key.trim() + "%' or last_name like N'%" + key.trim() + "%')";
            } else {
                try {
                    int key_num = Integer.parseInt(key);
                    if (searchType.equals("phone")) {
                        sql += " where (phone like N'%0" + key_num + "%')";
                    } else if (searchType.equals("employeID")) {
                        sql += " where employee_id = " + key_num + ")";
                    }
                } catch (Exception e) {
                    sql += ")";
                }
            }
        }
        try {
            PreparedStatement pstm = connection.prepareStatement(sql);
            ResultSet rs = pstm.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            System.out.println("getSizeOfListA: " + e);
        }
        return 0;
    }

    public List<Employee> getListByPage(int start, int top, String key, String searchType) {
        List<Employee> data = new ArrayList<>();
        String sql = "SELECT TOP " + top + " [employee_id]"
                + "      ,[first_name]\n"
                + "      ,[last_name]\n"
                + "      ,[gender]\n"
                + "      ,[date_of_birth]\n"
                + "      ,[phone]\n"
                + "      ,[address]\n"
                + "      ,[department_name]\n"
                + "      ,[remark]\n"
                + "  FROM [JWD_L_A101].[dbo].[Employee]\n"
                + "  where employee_id>all (SELECT TOP " + start + " [employee_id]\n"
                + "  FROM [JWD_L_A101].[dbo].[Employee]";
        try {
            if (key != null && !key.isEmpty()) {
                if (searchType.equals("name")) {
                    System.out.println(searchType);
                    sql += " where (first_name like N'%" + key.trim() + "%' or last_name like N'%" + key.trim() + "%'))";
                    sql += " and (first_name like N'%" + key.trim() + "%' or last_name like N'%" + key.trim() + "%')";
                } else {
                    try {
                        int key_num = Integer.parseInt(key);
                        if (searchType.equals("phone")) {
                            sql += " where (phone like N'%0" + key_num + "%'))";
                            sql += " and (phone like N'%0" + key_num + "%')";
                        } else if (searchType.equals("employeID")) {
                            sql += " where employee_id = " + key_num + ")";
                        }
                    } catch (Exception e) {
                        sql += ")";
                    }
                }

            } else {
                sql += ")";
            }
            //System.out.println(sql);
            PreparedStatement stm = connection.prepareStatement(sql);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                String employee_id = rs.getString(1);
                String first_name = rs.getString(2);
                String last_name = rs.getString(3);
                String gender = rs.getString(4);
                switch (Integer.parseInt(gender)) {
                    case 1:
                        gender = "male";
                        break;
                    case 0:
                        gender = "female";
                        break;
                    default:
                        gender = "null";
                        break;
                }
                String date_of_birth = rs.getString(5);
                String phone = rs.getString(6);
                String address = rs.getString(7);
                String department_name = rs.getString(8);
                String remark = rs.getString(9);
                Employee employee = new Employee(employee_id, first_name, last_name, gender, date_of_birth, phone, address, department_name, remark);
                data.add(employee);
            }
        } catch (SQLException e) {
            System.out.println("getListByPageA: " + e);
        }
        return data;
    }

}
