/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Entity.User;
import dal.DBContext;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author vinh1
 */
public class LoginDAO extends DBContext {

    public User checkLoginUser(String userName, String pass) {
        String sql = "select [account],[password],[status] from [Account] where account = ? and password = ?";
        try {
            PreparedStatement st = connection.prepareStatement(sql);
            st.setString(1, userName);
            st.setString(2, pass);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                User u = new User(rs.getString("account"),
                        rs.getString("password"),
                        rs.getInt("status"));
                return u;
            }
        } catch (SQLException e) {
            System.out.println("error login db");
        }
        return null;
    }
    
    public boolean checkDuplicate(String account) {
        
        String strSelect = "SELECT *  FROM [Account] where account = ?";
        try {
            PreparedStatement st = connection.prepareStatement(strSelect);
            st.setString(1, account);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                return false;
            }
        } catch (SQLException e) {
            System.err.println("error db" + e.getMessage());
        }
        return true;
    }

    public void addAccount(String account, String email, String password, int status, int employee_id) {
        String insert = "INSERT INTO [dbo].[Account]\n"
                + "            ([account]\n"
                + "           ,[email]\n"
                + "           ,[password]\n"
                + "           ,[status]\n"
                + "           ,[employee_id])\n"
                + "     VALUES\n"
                + "           (?,?,?,?,?)";
        System.out.println(insert);
        try {
            PreparedStatement ps = connection.prepareStatement(insert);
            ps.setString(1, account);
            ps.setString(2, email);
            ps.setString(3, password);
            ps.setInt(4, status);
            ps.setInt(5, employee_id);
            ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Create Account Error!!");
        }
    }
}
