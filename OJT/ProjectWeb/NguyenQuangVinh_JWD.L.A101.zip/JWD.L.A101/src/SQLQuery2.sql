
CREATE TABLE  Employee (
    employee_id INT PRIMARY KEY IDENTITY(1,1),
    first_name VARCHAR(255),
    last_name VARCHAR(255),
    gender int,
	date_of_birth date,
    phone VARCHAR(255),
    address VARCHAR(255),
    department_name VARCHAR(255),
    remark VARCHAR(1000)
);
GO
GO
CREATE TABLE  Account (
    account_id INT PRIMARY KEY not  null,
    account VARCHAR(255) not  null,
    email VARCHAR(255) not  null,
	password VARCHAR(255),
	status int,
	employee_id INT,
    FOREIGN KEY (employee_id) REFERENCES Employee(employee_id)
);