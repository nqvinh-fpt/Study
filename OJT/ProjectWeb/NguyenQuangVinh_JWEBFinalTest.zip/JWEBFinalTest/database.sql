

CREATE TABLE Account (
    account VARCHAR(20) PRIMARY KEY NOT NULL,
    password VARCHAR(30) NOT NULL,
    phone VARCHAR(11),
    balance BIGINT
	);

CREATE TABLE TransactionHistory (
    Transaction_id INT IDENTITY(1,1),
    amount BIGINT,
    transaction_note VARCHAR(255),
	account_receive VARCHAR(20) ,
	account_transfer VARCHAR(20) ,
    FOREIGN KEY (account_transfer) REFERENCES Account(account)
);


