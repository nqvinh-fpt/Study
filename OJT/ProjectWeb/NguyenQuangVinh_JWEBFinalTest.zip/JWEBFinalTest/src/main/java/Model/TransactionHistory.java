/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author vinh1
 */
public class TransactionHistory {
    private int Transaction_id;
    private long amount;
    private String transaction_note;
    private String account_transfer;

    public TransactionHistory() {
    }

    public TransactionHistory(int Transaction_id, long amount, String transaction_note, String account_transfer) {
        this.Transaction_id = Transaction_id;
        this.amount = amount;
        this.transaction_note = transaction_note;
        this.account_transfer = account_transfer;
    }

    public int getTransaction_id() {
        return Transaction_id;
    }

    public void setTransaction_id(int Transaction_id) {
        this.Transaction_id = Transaction_id;
    }

    public long getAmount() {
        return amount;
    }

    public void setAmount(long amount) {
        this.amount = amount;
    }

    public String getTransaction_note() {
        return transaction_note;
    }

    public void setTransaction_note(String transaction_note) {
        this.transaction_note = transaction_note;
    }

    public String getAccount_transfer() {
        return account_transfer;
    }

    public void setAccount_transfer(String account_transfer) {
        this.account_transfer = account_transfer;
    }
    
    
}
