/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import DAL.DBContext;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author vinh1
 */
public class TransferDAO extends DBContext {

    public void addTransfer(int Transaction_id, long amount, String transaction_note, String account_receive, String account_transfer) {
        String insert = "INSERT INTO [dbo].[TransactionHistory]\n"
                + "           ([Transaction_id]\n"
                + "           ,[amount]\n"
                + "           ,[transaction_note]\n"
                + "           ,[account_receive]\n"
                + "           ,[account_transfer])\n"
                + "     VALUES\n"
                + "           (?,?,?,?,?)";
        try {
            PreparedStatement ps = connection.prepareStatement(insert);
            ps.setInt(1, Transaction_id);
            ps.setLong(2, amount);
            ps.setString(3, transaction_note);
            ps.setString(4, account_receive);
            ps.setString(5, account_transfer);
            ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Create addTransfer Error!!" + e);
        }
    }

    public int getTransferLast() {
        try {
            String sql = "SELECT COUNT (*)\n"
                    + "FROM [TransactionHistory]";
            PreparedStatement st = connection.prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                String Transaction_id = rs.getString(1);
                return Integer.parseInt(Transaction_id);
            }
        } catch (Exception e) {
            System.out.println("getListUser: " + e.getMessage());
        }
        return 0;
    }
    
    public boolean updateTransfer(String account, long newBalance) {
        String update = "UPDATE Account SET balance= "+newBalance+" WHERE  account= '"+account+"'";
        try {
                PreparedStatement up = connection.prepareStatement(update);
                up.executeUpdate();
                return true;
            
        } catch (SQLException e) {
            System.out.println("Change TransactionHistory Error");
        } 
        return false;
    }

}
