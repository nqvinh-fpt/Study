import React from "react";


const Products = () => {
    return (

        <div class="container text-center mt-5">
            <h2>========================PRODUCTS========================</h2>

            <div className="row justify-content-center">
            <div class="card col-md-3 mx-2" style={{ width: '18rem' }}>
                <img src="https://images2.thanhnien.vn/528068263637045248/2023/4/28/thumb-1682682944764488512878.jpg" class="card-img-top img-fluid" alt="..." style={{ height: '150px' }}/>
                <div class="card-body">
                    <h5 class="card-title">LIÊN MINH HUYỀN THOẠI</h5>
                    <p class="card-text"></p>
                    <a href="#" class="btn btn-primary">View All</a>
                </div>
            </div>
            <div class="card col-md-3 mx-2" style={{ width: '18rem' }}>
                <img src="https://cdn.tgdd.vn/GameApp/4/221941/Screentshots/lien-minh-huyen-thoai-game-moba-pho-bien-nhat-the-gioi-21-05-2020-2.jpg" class="card-img-top" alt="..."style={{ height: '150px' }} />
                <div class="card-body">
                    <h5 class="card-title">GARENA LIÊN QUÂN MOBILE</h5>
                    <p class="card-text"></p>
                    <a href="#" class="btn btn-primary">View All</a>
                </div>
            </div>
            </div>
        </div>


    )
}

export default Products;